/*********************************************************************************************************
 *        ___             __               __                                                        
 *       /   |  _________/ /__  ________  / /__                                                      
 *      / /| | / ___/ __  / _ \/ ___/ _ \/ //_/                                                      
 *     / ___ |(__  ) /_/ /  __/ /  /  __/ ,<                                                         
 *    /_/  |_/____/\__,_/\___/_/   \___/_/|_|____                 __           __  _                 
 *                                          / __ \_________  ____/ /_  _______/ /_(_)___  ____  _____
 *                                         / /_/ / ___/ __ \/ __  / / / / ___/ __/ / __ \/ __ \/ ___/
 *                                        / ____/ /  / /_/ / /_/ / /_/ / /__/ /_/ / /_/ / / / (__  ) 
 *                                       /_/   /_/   \____/\__,_/\__,_/\___/\__/_/\____/_/ /_/____/  
 *                                                                                                   
*********************************************************************************************************/
*
*	Lucas P Nepomuceno
*	Louise C Heggendorn
*
**********************************************************************************************************/

Starting the Game
	At the title screen, press H to start a new game.

How To Play
		The goal in Pongify is to hit the walls in the order displayed on top of the screen. You do 
	that by hitting the ball on the walls. The letter N stands for north and represents the top (north)
	wall. The same is true for S, the south wall, E, the east wall and W, the west wall.
		It is possible to teleport from one side the room to the other, by moving in a straight line
	in any direction, meaning, if you get out of the screen to the right, you will end up on the left
	side of the screen.

Controls
	Movement
		W - move the paddle up
		A - move the paddle left
		S - move the paddle down
		D - move the paddle right
	Other
		H - hit the machine
		T - brings the paddle back to the middle